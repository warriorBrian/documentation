## 声明

**非商业目的**

**非盈利目的**

**在使用互联网来源时会注明来源或保留图片水印，以此作为参考声明。**


此文档中包含但不限于文章、图片、链接等，如果存在侵权请致信: cn_brian@163.com

## 关于参考

**相关参考(以下称为参考)会在以下进行统一声明，注明来源于互联网地址及作者信息。**

**文章中没有声明参考地址则使用统一声明。**

* **Lodash相关参考:**
  * [yeyuqiudeng( 对角另一面 ): pocket-lodash源码分析](https://github.com/yeyuqiudeng/pocket-lodash)
  * [mdn web docs](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript)

* **javascript算法参考:**
	* [sisterAn JavaScript-Algorithms](https://github.com/sisterAn/JavaScript-Algorithms)
	* [mdn web docs](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript)
	* [30 seconds of code](https://www.30secondsofcode.org/)


## License
<a rel="license" href="http://creativecommons.org/licenses/by-nc/4.0/"><img alt="知识共享许可协议" style="border-width:0" src="https://i.creativecommons.org/l/by-nc/4.0/88x31.png" /></a><br />本作品采用<a rel="license" href="http://creativecommons.org/licenses/by-nc/4.0/">知识共享署名-非商业性使用 4.0 国际许可协议</a>进行许可。