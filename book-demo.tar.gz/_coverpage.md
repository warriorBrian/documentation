![logo](https://docsify.js.org/_media/icon.svg)

# 文档

> 卑鄙是卑鄙者的通行证，高尚是高尚者的墓志铭。
>
> ——北岛《回答》

<!-- * 前端框架：vue-cli、vue-router、axios、vuex
* UI类库：Mint-UI、Vant
* 后端数据接口：Express、MongoDB -->

[Get Started](index.md)

![color](#f0f0f0)
